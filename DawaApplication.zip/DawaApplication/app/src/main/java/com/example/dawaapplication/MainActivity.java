package com.example.dawaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView btn_enr, btn_rechercher, btn_produit;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btn_enr = (ImageView) findViewById(R.id.imageView15);
        btn_produit = (ImageView) findViewById(R.id.imageView17);
        btn_rechercher = (ImageView) findViewById(R.id.imageView16);

        btn_enr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, produit.class);
                startActivity(intent);
            }
        });
        btn_produit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivityProduit.class);
                startActivity(intent);
            }
        });

        btn_rechercher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RECHERCHE.class);
                startActivity(intent);
            }
        });
    }
}