package com.example.dawaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText login, password;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = (EditText)findViewById(R.id.login);
        password = (EditText)findViewById(R.id.pss);
        btn = (Button)findViewById(R.id.btn_con);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(login.getText().toString().equals("") && password.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this, "Veuillez remplir les champs vides s" +
                            "vp", Toast.LENGTH_SHORT).show();
                }else {
                    if (login.getText().toString().equals("admin") && password.getText().toString().equals("admin"))
                    {
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                    }else
                        Toast.makeText(LoginActivity.this, "Login ou mot de passe incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}