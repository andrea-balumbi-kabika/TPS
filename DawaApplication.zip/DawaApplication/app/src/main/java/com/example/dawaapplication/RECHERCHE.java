package com.example.dawaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;

public class RECHERCHE extends AppCompatActivity {
    private EditText prix;
    private Button btn_rec, btn_ajout;
    private MultiAutoCompleteTextView mutl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_r_e_c_h_e_r_c_h_e);
        prix = (EditText)findViewById(R.id.prix);
        btn_ajout= (Button)findViewById(R.id.btn_ajout);
        btn_rec = (Button)findViewById(R.id.btn_rec);
        mutl = (MultiAutoCompleteTextView)findViewById(R.id.mult);


        btn_rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mutl.setText(prix.getText().toString());
            }
        });
        btn_ajout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RECHERCHE.this, produit.class);
                startActivity(intent);
            }
        });
    }
}