package com.example.dawa;

import android.widget.EditText;
import android.widget.TextView;

public class Produit {
    private String  nomProduit;
    private int qte;
    private int prix;

    public Produit(String nomProduit, int qte, int prix) {
        this.nomProduit = nomProduit;
        this.qte = qte;
        this.prix = prix;
    }

    public Produit(EditText nomProduit, EditText qte, EditText prix) {
    }

    public String getNomProduit() {
        return nomProduit;
    }

    public void setNomProduit(String nomProduit) {
        this.nomProduit = nomProduit;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }
}
