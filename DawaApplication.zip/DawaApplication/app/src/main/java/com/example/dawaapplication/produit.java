package com.example.dawaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class produit extends AppCompatActivity {
  public EditText nom, qte, prix;
    private ImageView btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produit);

        nom = (EditText)findViewById(R.id.nom);
        qte = (EditText)findViewById(R.id.qte);
        prix = (EditText)findViewById(R.id.prix);
        btn = (ImageView)findViewById(R.id.btn_produit_enr);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(produit.this, "nomProduit="+nom.getText().toString()+", qte = "+qte.getText().toString()+"prix="+prix.getText().toString()+",Vos données sont enregistrées avec succè ", Toast.LENGTH_LONG).show();
            }
        });
    }
}