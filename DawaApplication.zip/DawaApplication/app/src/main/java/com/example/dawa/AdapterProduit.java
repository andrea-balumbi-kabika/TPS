package com.example.dawa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.dawaapplication.R;

import java.util.ArrayList;
import java.util.List;

public class AdapterProduit extends BaseAdapter {
    private List<Produit> produits = new ArrayList<>();
    private Context context;
    private LayoutInflater inflater;

    public AdapterProduit(List<Produit> horaires, Context context) {
        this.produits = horaires;
        this.context = context;
        this.inflater = inflater.from(context);
    }

    @Override
    public int getCount() {
        return produits.size();
    }

    @Override
    public Object getItem(int position) {
        return produits.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        view = inflater.inflate(R.layout.adapteur_produit, null);
        Produit item = (Produit) getItem(position);
        String nom = item.getNomProduit();
        int qte = item.getQte();
        int prix = item.getPrix();


        TextView nomT = view.findViewById(R.id.textView);
        nomT.setText(nom);
        TextView qteT = view.findViewById(R.id.textView2);
        qteT.setText(String.valueOf(qte));
        TextView prixT = view.findViewById(R.id.textView3);
        prixT.setText(String.valueOf(prix));
        return view;
    }
}
