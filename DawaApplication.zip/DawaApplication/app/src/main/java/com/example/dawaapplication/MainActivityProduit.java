package com.example.dawaapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.dawa.AdapterProduit;
import com.example.dawa.Produit;
import com.example.dawaapplication.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivityProduit extends produit {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_produit);
        List<Produit> produit = new ArrayList<>();
        produit.add(new Produit(super.nom, super.qte,super.prix));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));
        produit.add(new Produit("Paracemol", 23, 23));

        ListView listView = findViewById(R.id.liste);
        listView.setAdapter(new AdapterProduit(produit, MainActivityProduit.this));

    }
}